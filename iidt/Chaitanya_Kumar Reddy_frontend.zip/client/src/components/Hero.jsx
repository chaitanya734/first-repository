import React from "react";
import image from "../images/heroimg.jpg";
import "../styles/hero.css";

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>
          The greatest wealth<br />
          is health.
        </h1>
        <p>
        "Health is the foundation of a fulfilling life, empowering us to pursue our passions with vigor and vitality. It's not just the absence of illness, but the harmonious balance of mind, body, and spirit. Prioritizing health is a lifelong journey, a commitment to nurturing ourselves and embracing the gift of well-being."
        </p>
      </div>
      <div className="hero-img">
        <img
          src={image}
          alt="hero"
        />
      </div>
    </section>
  );
};

export default Hero;
