import React from "react";
import image from "../images/aboutimg.jpg";

const AboutUs = () => {
  return (
    <>
      <section className="container">
        <h2 className="page-heading about-heading">About Us</h2>
        <div className="about">
          <div className="hero-img">
            <img
              src={image}
              alt="hero"
            />
          </div>
          <div className="hero-content">
            <p>
            At Innovation Pioneers, we're trailblazing the future of healthcare with cutting-edge technology. Our team of passionate experts, driven by a shared mission for better health, are dedicated professionals at the forefront of innovation. As your trusted partner, we provide seamless solutions for all your medical appointment needs, ensuring convenience, efficiency, and peace of mind for every step of your healthcare journey.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutUs;
