const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = process.env.PORT || 5000;

// MongoDB connection
PORT=5000

mongoose.connect('mongodb+srv://aravind12:aravind%4012@database.bzgvzwm.mongodb.net/todo?retryWrites=true&w=majority&appName=database', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// Express routes
app.get('/', (req, res) => {
  res.send('Welcome to Express Server');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});