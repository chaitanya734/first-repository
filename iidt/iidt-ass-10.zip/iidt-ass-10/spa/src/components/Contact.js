import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Contact form will go here.</p>
    </div>
  );
};

export default Contact;