import React, { useState } from 'react';
import './Search.css';

function Search() {
    const [searchData,setSearchData] = useState([]);
    const [books, setBooks] = useState([]);

    const handleChange = (event) => {
        setSearchData(event.target.value);
      };
      const handleSubmit = async (event) => {
        event.preventDefault();
        try {
        const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=Harry%20Potter`);
    
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          const data = await response.json();
          setBooks(data.items || []);
        } catch (error) {
          console.error('Error fetching books:', error);
        }

    }

    return ( 
        <div>
      <form onSubmit={handleSubmit} style={{margin:"2%"}}>
        <input
          type="text"
          placeholder="Enter book title"
          value={searchData}
          onChange={handleChange}
        />
        <button type="submit">Search</button>
      </form>
      <hr />
      <ul >
      <div className='box'>
        {books.map((book) => (
          
          <div key={book.id}>
                 <img src={book.volumeInfo.imageLinks.thumbnail} alt='img'/>
                  <h4>{book.volumeInfo.authors} </h4>
                  <h4>{book.volumeInfo.title}</h4>
          </div>
         
        ))}
         </div>
      </ul>
    </div>

     );
}
export default Search;