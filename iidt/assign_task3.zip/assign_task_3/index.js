
function validateForm() {

    var name = document.forms["myform"]["name"].value;
    var email=document.forms["myform"]["mail"].value;
    var pass=document.forms["myform"]["pass"].value;
    var ph=document.forms["myform"]["ph"].value;
    if (name == "" ||name==null ) {
        alert("Name must be filled out");
        return false
    }
    var atpos=email.indexOf("@");
    var dotpos=email.lastIndexOf(".");
    if( atpos<1 || dotpos<atpos+2 ||dotpos+2>=email.length)
    {
        alert("please enter a valid email address");
         return false;
   }
   if(pass.length<6){
    alert("Password must contain atleast 8");
    return false;
   }
   if(pass.length>16){
    alert("Password must be less than 16 character");
    return false;
   }
   
   if(ph.length=="" || ph.length==null ||ph.length!=10)
   {
    alert("Phone number must contain 10 digits");
    return false;
   }
   

  }