import React from 'react';

const WeatherDisplay = ({ weather }) => {
  return (
    <div className="weather-display">
      {weather ? (
        <>
          <h2>Current Weather</h2>
          <div>
            <div>Temperature: {weather.temperature}°C</div>
            <div>Humidity: {weather.humidity}%</div>
            <div>Wind Speed: {weather.windSpeed} m/s</div>
            <div>Weather: {weather.weather}</div>
          </div>
        </>
      ) : (
        <p>No weather data available</p>
      )}
    </div>
  );
};

export default WeatherDisplay;
