function changeColor()
{
    var id=document.getElementById("paragraph");
    id.style.color="red";
}