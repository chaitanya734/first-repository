import React from 'react';
import TeamMember from './TEamMember';
function About() {
    return ( <section style={{display:"flex" , justifyContent:"space-around"}}>
        <TeamMember name='john' position='Founder' company='xyz' LinkedInUrl=''/>
        <TeamMember name='Jane' position='Co-Founder' company='Abc' LinkedInUrl=''/>
        <TeamMember name='Josh' position='Manager' company='Wxyz' LinkedInUrl=''/>

    </section>);
}

export default About;