import React from 'react';
function Home() {
    return (  <>
    <h1>This section one in the Home</h1>
    <h1>This section Two in the Home</h1>
    <h1>This section Three in the Home</h1>
    <p>
        copyright &copy;
        <br/>
        Made with &hearts; in India
    </p>
    </>);
}

export default Home;