import React from 'react';
function TeamMember(props) {
    return (  <div>
        <h1>{props.name}</h1>
        <p>{props.position},{props.company}</p>
        <a href={props.LinkedInUrl}>Connect on LinkedIn</a>
    </div>);
}

export default TeamMember;