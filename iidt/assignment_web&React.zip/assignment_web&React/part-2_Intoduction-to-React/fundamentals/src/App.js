
import './App.css';
import Form from './Form';
import Greeting from './Greeting';

function App() {
  return (
    <>
    <h1>Hello World!--This is a first React app</h1>
    <Greeting name="Aravind"/>
    <Form />
    </>
  );
}

export default App;
