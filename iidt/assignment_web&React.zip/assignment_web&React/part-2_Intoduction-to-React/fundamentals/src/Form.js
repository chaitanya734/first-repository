import React, { useState } from 'react';
function Form() {

 
const [value,setValue]=useState("");
const [inputValue, setInputValue]=useState("");


const handleInputChange=(value)=>{
    setValue(value);
    

};
const replaceWithGreetings=()=>{
    setInputValue("How are you ,"+(value));

};  
    return (  
    
    
    <div>

    <input type='text' placeholder='Enter your name' onChange={(e)=> handleInputChange(e.target.value)} /><br />
      <button onClick={replaceWithGreetings}>Submit</button>

      <h1>{inputValue}</h1>
    </div>);
}

export default Form;