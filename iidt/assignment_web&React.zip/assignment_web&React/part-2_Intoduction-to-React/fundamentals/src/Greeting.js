import React from 'react';
function Greeting(props) {
    return ( 
        <h1>Good to see you, {props.name}</h1>
     );
}

export default Greeting;