const express=require("express");
const bodyParse=require("body-parser")
const { v4:uuidv4}=require("uuid");

const app=express();
app.use(bodyParse.json());

let contacts=[
    {
        id:uuidv4(),
        name:"john",
        email:"john@gamil.com",
        phone:"123-123-4567",
        address:"123 Main st",
    },
    {
        id:uuidv4(),
        name:"vijay",
        email:"vijay@gamil.com",
        phone:"321-123-2321",
        address:"234 street",
    },
    {
        id:uuidv4(),
        name:"ajay",
        email:"ajay@gamil.com",
        phone:"342-421-1232",
        address:"210 Main Road",
    },
    {
        id:uuidv4(),
        name:"bujji",
        email:"bujji@gamil.com",
        phone:"235-029-1834",
        address:"342 Ford street",
    },
]

//get all contacts
app.get("/contacts",(req,res)=>{
        res.json(contacts)
});
//specific
app.get("/contacts/:id",(req,res)=>{
    let id=req.params.id;
    let contact =contacts.find((contact)=>contact.id===id);
    if(!contact){
       return res.status(404).json({message:"contact not found"});
    }
    res.json(contact);
});
//add new
app.post("/contacts",(req,res)=>{
    let {name,email,phone,address}=req.body;
    let id=uuidv4();
    let newContact={
        id,
        name,
        email,
        phone,
        address,
    };
    contacts.push(newContact);
    res.status(201).json(newContact)

});
//update
app.put("/contacts/:id",(req,res)=>{
    let {name,email,phone,address}=req.body;
    let id=req.params.id;
    let index =contacts.findIndex((contact)=>contact.id===id);
    if(index==-1){
      return res.status(404).json({message:"contact not found"});
    }
    contacts[index]={id,name,email,phone,address};
    res.json(contacts[index]);
});
//delete
app.delete("/contacts/:id",(req,res)=>{
    let id=req.params.id;
    let index =contacts.findIndex((contact)=>contact.id===id);
    if(index==-1){
      return res.status(404).json({message:"contact not found"});
    }
    const deletedContact=contacts.splice(index,1);
    res.json(deletedContact);
});

const PORT=3000;
app.listen(PORT,(req,res)=>{
    console.log(`server is running on the port ${PORT}`)
})