import React from 'react';
function Product(props) {
    return ( 

        <div className="product" style={{ width: "40%", marginBottom: "50px" ,marginLeft:"20px"}}>
            <img src={props.productImg} alt="product Image"  style={{ width:"250px" ,height:"250px"}}/>
            <h2>{props.title}</h2>
            <h2>{props.price}</h2>
        </div>

     );
}

export default Product;